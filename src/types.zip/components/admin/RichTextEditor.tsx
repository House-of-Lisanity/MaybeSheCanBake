"use client";

export default function RichTextEditor({
  value,
  onChange,
}: {
  value: string;
  onChange: (text: string) => void;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      rows={6}
      placeholder="Rich text (Markdown or HTML for now)"
    />
  );
}
