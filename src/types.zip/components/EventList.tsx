import { EventType } from "@/types/event"; // ✅ ADDED

type Props = {
  events: EventType[];
  isAdmin?: boolean; // ✅ ADDED
  onEdit?: (event: EventType) => void; // ✅ ADDED
};

export default function EventList({ events, isAdmin = false, onEdit }: Props) {
  return (
    <ul className="event-list">
      {events.map((event) => (
        <li key={event._id}>
          <strong>{event.title}</strong> –{" "}
          {new Date(event.date).toLocaleDateString()} <br />
          <em>{event.location}</em>
          {event.description && <p>{event.description}</p>}
          {/* ✅ ADMIN Edit Button */}
          {isAdmin && onEdit && (
            <button onClick={() => onEdit(event)} className="edit-event-btn">
              Edit
            </button>
          )}
        </li>
      ))}
    </ul>
  );
}
