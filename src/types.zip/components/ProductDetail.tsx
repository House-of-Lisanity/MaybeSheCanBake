"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ProductType } from "@/types/product";
import Navbar from "@/components/NavBar";
import { useRouter } from "next/navigation"; // ✅ ADD
import ProductModal from "@/components/admin/ProductModal"; // ✅ ADD

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<ProductType | null>(null);
  // ✅ TEMP admin toggle – replace with your real check later
  const isAdmin = true;

  const [showModal, setShowModal] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await fetch(`/api/products/${id}`);
        const data = await res.json();
        setProduct(data);
      } catch (err) {
        console.error("Failed to load product:", err);
      }
    };

    fetchProduct();
  }, [id]);

  const refetch = async () => {
    if (!id) return;
    const res = await fetch(`/api/products/${id}`);
    const data = await res.json();
    setProduct(data);
  };

  const handleDelete = async () => {
    if (!product?._id) return;
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/products/${product._id}`, {
      method: "DELETE",
    });
    if (res.ok) {
      router.push("/products");
    } else {
      console.error("Failed to delete product");
    }
  };

  if (!product) return <p>Loading...</p>;

  return (
    <section className="product-detail">
      <Navbar alwaysScrolled />

      <div className="detail-wrapper">
        <div className="image-column">
          <Image
            src={product.imageUrl ?? "/placeholder.png"}
            alt={product.name}
            width={600}
            height={600}
            className="product-image"
            priority
          />
        </div>

        <div className="info-column">
          <h1>{product.name}</h1>
          <p className="description">{product.description}</p>
          <p className="price">
            <strong>Price:</strong> {product.price}
          </p>

          {Array.isArray(product.highlights) &&
            product.highlights.length > 0 && (
              <div className="product-section">
                <h3>Highlights</h3>
                <ul>
                  {product.highlights.map((tag, idx) => (
                    <li key={idx}>{tag}</li>
                  ))}
                </ul>
              </div>
            )}

          {Array.isArray(product.ingredients) &&
            product.ingredients.length > 0 && (
              <div className="product-section">
                <h3>Ingredients</h3>
                <ul>
                  {product.ingredients.map((ing, idx) => (
                    <li key={idx}>{ing}</li>
                  ))}
                </ul>
              </div>
            )}

          <nav className="product-nav">
            <Link href="/products">← Return to Products</Link>
            <span className="divider">|</span>
            <Link href="/">Return to Home</Link>
          </nav>
          {isAdmin && (
            <div
              className="admin-actions"
              style={{ marginTop: "1rem", display: "flex", gap: ".5rem" }}
            >
              <button type="button" onClick={() => setShowModal(true)}>
                Edit Product
              </button>
              <button type="button" onClick={handleDelete}>
                Delete Product
              </button>
            </div>
          )}
        </div>
      </div>
      {isAdmin && showModal && (
        <ProductModal
          product={product}
          onClose={() => setShowModal(false)}
          onSaved={refetch}
        />
      )}
    </section>
  );
}
