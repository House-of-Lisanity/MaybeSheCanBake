const demoGallery = [
  {
    url: "/market1.jpg",
    caption: "Baking in progress",
  },
  {
    url: "/market2.jpg",
    caption: "Farmers Market Booth",
  },
  {
    url: "/market3.jpg",
    caption: "Fresh from the oven",
  },
  {
    url: "/market4.jpg",
    caption: "Local produce",
  },
];

export default demoGallery;
