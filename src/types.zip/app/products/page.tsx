// app/products/page.tsx
import ProductCatalog from "@/sections/ProductCatalog";

export default function ProductsPage() {
  return <ProductCatalog />;
}
