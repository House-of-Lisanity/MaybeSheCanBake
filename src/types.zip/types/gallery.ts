export interface GalleryType {
  _id?: string;
  url: string;
  caption?: string;
  alt?: string;
  createdAt?: string;
  updatedAt?: string;
}
