export interface EventType {
  _id?: string;
  title: string;
  date: string; // ISO format (e.g. "2025-08-21")
  location: string;
  time: string; // e.g. "10:00 AM – 2:00 PM"
  description?: string;
  isPublished?: boolean;
}
