const demoReviews = [
  {
    name: "Avery R.",
    content:
      "Hands down the best lemon loaf I’ve ever had. Please open a full bakery!",
    date: "2024-07-01",
  },
  {
    name: "Jordan M.",
    content:
      "The chocolate chip cookies were next level. Bought 3, ate 3... instantly.",
    date: "2024-07-05",
  },
  {
    name: "Sam K.",
    content:
      "I can't go to the market without grabbing one of her brownies. Addicted.",
    date: "2024-07-10",
  },
];

export default demoReviews;
