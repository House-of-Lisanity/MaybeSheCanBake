// src/models/Product.ts
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const ProductSchema = new Schema({
  name: { type: String, required: true },
  category: { type: Schema.Types.ObjectId, ref: "Category", required: true },
  price: { type: String },
  description: { type: String },
  ingredients: [{ type: String }],
  imageUrl: { type: String },
  isAvailable: { type: Boolean, default: true },
});

export const Product = models.Product || model("Product", ProductSchema);
