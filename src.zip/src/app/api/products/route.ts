// maybeshecanbake/src/app/api/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { Product } from "@/models/Product";
import { Category } from "@/models/Category";
import { Types } from "mongoose";

// src/app/api/products/route.ts
export async function GET(req: NextRequest) {
  try {
    await connectToDatabase();
    // Optional: filtering by category id or name.
    const category = req.nextUrl.searchParams.get("category");
    const query: Record<string, unknown> = {};
    if (category && category !== "All") {
      query.category = category; // Use category _id for filtering
    }
    // Populate the category object in the response
    const products = await Product.find(query).populate("category").lean();
    return NextResponse.json(products);
  } catch (error) {
    console.error("Failed to fetch products:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// CREATE a new product
export async function POST(req: NextRequest) {
  try {
    await connectToDatabase();
    const body = await req.json();

    // Validate category: check that it exists
    if (!body.category || !Types.ObjectId.isValid(body.category)) {
      return NextResponse.json(
        { error: "Invalid or missing category id." },
        { status: 400 }
      );
    }
    const categoryExists = await Category.exists({ _id: body.category });
    if (!categoryExists) {
      return NextResponse.json(
        { error: "Category not found." },
        { status: 404 }
      );
    }

    const newProduct = await Product.create(body);
    return NextResponse.json(newProduct, { status: 201 });
  } catch (error) {
    console.error("Failed to create product:", error);
    return NextResponse.json(
      { error: "Failed to create product." },
      { status: 400 }
    );
  }
}
