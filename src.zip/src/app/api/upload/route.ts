import { NextRequest, NextResponse } from "next/server";
import cloudinary from "@/lib/cloudinary";

export async function POST(req: NextRequest) {
  try {
    // Parse FormData for file upload
    const formData = await req.formData();
    const file = formData.get("file");
    if (!file) throw new Error("No file uploaded.");

    if (!(file instanceof Blob)) {
      throw new Error("Uploaded file is not a Blob.");
    }

    // Convert file to base64 string
    const buffer = await file.arrayBuffer();
    const base64 = Buffer.from(buffer).toString("base64");

    // Upload to Cloudinary
    const response = await cloudinary.uploader.upload(
      `data:${file.type};base64,${base64}`,
      {
        upload_preset: "ml_default", // or your preset
      }
    );

    return NextResponse.json(
      { url: response.secure_url, public_id: response.public_id },
      { status: 200 }
    );
  } catch (err) {
    const errorMessage =
      err instanceof Error ? err.message : "An unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}
