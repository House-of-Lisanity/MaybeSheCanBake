import { CategoryType } from "./category";
export interface ProductType {
  _id: string;
  name: string;
  category: string | CategoryType;
  price?: string;
  description?: string;
  highlights?: string[];
  ingredients?: string[];
  imageUrl?: string;
  isAvailable: boolean;
}
